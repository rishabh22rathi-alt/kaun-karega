export function ts() {
  return new Date().toISOString();
}
