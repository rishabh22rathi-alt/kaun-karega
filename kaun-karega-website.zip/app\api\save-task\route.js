import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const { phone, taskTitle, taskDescription, location, budget } = body;

    if (!phone || !taskTitle || !taskDescription || !location) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Google Apps Script URL
    const SHEET_URL =
      "https://script.google.com/macros/s/AKfycby3WrvppRyQkfjE8hr8AL05IEqTwqB0Vylyup4QVXTO4N8knWLVZlTUDzQJqctpWGI/exec";

    // Send data to Google Sheet
    const response = await fetch(SHEET_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        type: "save_task",
        phone,
        taskTitle,
        taskDescription,
        location,
        budget: budget || "",
      }),
    });

    const result = await response.text();
    console.log("Google Sheet Response:", result);

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Save task error:", err);
    return NextResponse.json({ success: false }, { status: 500 });
  }
}
