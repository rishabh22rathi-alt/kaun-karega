export const SIDEBAR_TOGGLE_EVENT = "kk-sidebar-toggle";
